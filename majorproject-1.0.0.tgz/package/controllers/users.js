const User = require("../models/users.js");

module.exports.renderSignupForm =  (req, res)=>{
    res.render("users/signup.ejs");
};

module.exports.signup = async(req, res)=>{
    try{
    let { username, email, password} = req.body;
    const newUser = new User({ email, username});
    const registeredUser = await User.register(newUser, password);
    console.log(registeredUser);
    req.login(registeredUser, (err)=>{                          //throuugh  this you directly login after signup
        if(err) {
            return next(err);
        }
        req.flash("success", "Welcome To Wanderlust");
        res.redirect("/listings");
    });
 
    } catch (e){
         req.flash("error", e.message);
         res.redirect("/signup");
    }
};

module.exports.renderLoginForm = (req, res)=>{
    res.render("users/login.ejs");
};

module.exports.login =  async(req, res)=>{
    req.flash("success", "Welcome back to Wanderlust!");
    let redirectUrl = res.locals.redirectUrl || "/listings"
    res.redirect(redirectUrl);
};


module.exports.logout =  (req, res, next)=>{
    req.logOut((err)=>{
        if(err){
            return next(err);
        }
            req.flash("success", "You are Logged Out!");
            res.redirect("/listings");
    });
};